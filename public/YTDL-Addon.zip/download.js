
console.log("ytdl");

const dlURL = new URL(location.href);
const title = dlURL.searchParams.get("title");

const dlLink = document.createElement("a");
dlLink.innerText = `${title}`;
dlLink.href = dlURL.toString();
dlLink.download = `${title}.m4a`;
dlLink.style.display = "block";
dlLink.style.fontSize = "2em"
dlLink.target = "_blank"

dlLink.click();

window.close();