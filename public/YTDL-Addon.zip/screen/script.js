onload = async () => {
    const p = document.getElementById("linktest")
    const audioList = await chrome.runtime.sendMessage({ method: "getURL" })
    p.innerText = audioList.join(", ")


    // const c = document.getElementById("cookie")
    // const cookie = await chrome.runtime.sendMessage({ method: "cookie" })

    // c.innerText = JSON.stringify(cookie, null, "   ")
}