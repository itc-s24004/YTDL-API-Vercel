
const audioList = [];

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    // console.log(req.url)
    if (req.method == "getURL") {
        sendResponse(audioList);

    } else if (req.method == "cookie") {
        chrome.cookies.getAll({}, ((cookies)=>{
            sendResponse(cookies);
        }));

    } else {

        /**
         * @type {{domain: string}[]}
         */
        const cookies = req.cookies;

        // cookies.forEach(e => e.domain = "ytdl-api-vercel.vercel.app")


        fetch(req.url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(cookies)
            // credentials: "omit"
        })
        .then( async (response) => {

            /**
             * @type {YTData[]}
             */
            const json = await response.json();

            // json.forEach(data => {
            //     audioList.push(data.url)
            // })
            sendResponse(json)
        })
        .catch((error) => {
            console.log("ng")
            sendResponse(req.url)
        })
    }

  return true
});