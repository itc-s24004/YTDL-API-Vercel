/**
 * @typedef YTData
 * @property {string} url
 * 
 * 
 */

const dev = false


document.body.addEventListener("keydown", async (ev) => {
    if (ev.key == "@") {
        const url = new URL(location.href);
        const YTID = url.searchParams.get("v");
        
        if (YTID) {
            const link = dev ? `http://localhost:3000/api/ytdl/${YTID}` : `https://ytdl-api-vercel.vercel.app/api/ytdl/${YTID}`
            
            const titleContainer = document.getElementById("title");

            const title = titleContainer?.children?.[1]?.children[0].getAttribute("title");


            const audioList = titleContainer?.getElementsByTagName("audio");
            while (audioList && audioList.length > 0) {
                audioList.item(0)?.remove();
            }

            const dlLinkList = titleContainer?.getElementsByTagName("a");
            while (dlLinkList && dlLinkList.length > 0) {
                dlLinkList.item(0)?.remove();
            }

            const cookies = await chrome.runtime.sendMessage({ method: "cookie" })
            console.log(cookies);


            /**
             * @type {YTData[]}
             */
            const dataList = await chrome.runtime.sendMessage(
                { url: link, cookies: cookies }
            )
            console.log(dataList)

            dataList.forEach((data, i) => {

                const dlURL = new URL(data.url);
                dlURL.searchParams.set("title", title);

                const dlLink = document.createElement("a");
                dlLink.innerText = `${i+1}: ${title}`;
                dlLink.href = dlURL.toString();
                dlLink.download = `${YTID}`;
                dlLink.style.display = "block";
                dlLink.style.fontSize = "2em"
                dlLink.target = "_blank"

                const audio = document.createElement("audio");
                audio.src = data.url;
                audio.controls = true;
                audio.style.display = "block";




                titleContainer.appendChild(audio);
                titleContainer.appendChild(dlLink);
            })


        }
        

    }
})


console.log("front.js")